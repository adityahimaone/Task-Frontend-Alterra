import React from "react";
import './App.css';
import Home from './component/Home.jsx';

function App() {
  return (
    <div className="App">
      <Home />
    </div>
  );
}

export default App;
